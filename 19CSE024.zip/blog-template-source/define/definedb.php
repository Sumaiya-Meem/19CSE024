<?php
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASS", "");
define("DB_NAME", "php_oop");
define("TITLE", "Study Mate");
define("KEYWORDS", "JAVA,PHP,LARAVEL,CSS,HTML Tuitorials");

