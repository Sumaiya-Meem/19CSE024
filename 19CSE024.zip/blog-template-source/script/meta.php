<?php
	if(isset($_GET['pageid'])){
		$pagetitleid=$_GET['pageid'];
		$query="select * from page where id='$pagetitleid'";
            $pagequery=$db->select($query);
            if($pagequery){
                while($result=$pagequery->fetch_assoc()){ ?>
					<title><?php echo $result['name']; ?>-<?php echo TITLE; ?></title>
					<?php	} } } elseif(isset($_GET['post_id'])){ 

		$posttitleid=$_GET['post_id'];
		$query="select * from post where post_id='$posttitleid'";
            $pagequery=$db->select($query);
            if($pagequery){
                while($result=$pagequery->fetch_assoc()){ ?>
					<title><?php echo $result['title']; ?>-<?php echo TITLE; ?></title> 
					<?php	} } }  else{ ?>
						<title><?php echo $fm->title(); ?>-<?php echo TITLE; ?></title>
					<?php	} ?>
	
	<meta name="language" content="English">
	<meta name="description" content="It is a website about education">
	<?php
   if(isset($_GET['post_id'])){
	   $keyword_id=$_GET['post_id'];
	   $query="select * from post where post_id='$keyword_id'";
            $keyword=$db->select($query);
            if($keyword){
                while($result=$keyword->fetch_assoc()){ ?>
				<meta name="keywords" content="<?php echo $result['tags'];?>">
			<?php } } } else { ?>
				<meta name="keywords" content="<?php echo KEYWORDS;?>">
  <?php  } ?>

	<meta name="author" content="Delowar">