<?php include "inc/header.php";?>

<?php
   if(!isset($_GET['post_id']) || $_GET['post_id'] == NULL ){
	header("Location:404.php") ;
   }
   else{
	   $post_id=$_GET['post_id'];
   }
?>
	<div class="contentsection contemplete clear">
		<div class="maincontent clear">
			<div class="about">
			<?php
            $query="select * from post where post_id=$post_id";
			$post=$db->select($query);
			if($post){
				while($result=$post->fetch_assoc()){
           ?>
				<h2><?php echo $result['title']; ?></h2>
				<h4><?php echo  $fm->dateFormat($result['date']); ?> By <a href="#"><?php echo $result['author']; ?></a></h4>
				<img src="admin/<?php echo $result['image']; ?>" alt="post image"/>
				<?php echo $result['body']; ?>
		
			
	

				<div class="relatedpost clear">
					<h2>Related Post</h2>
					<?php 
					  $cat_id=$result['category'];
					  $relatedpost_query="select * from post where category='$cat_id' limit 6";
			          $relatedpost=$db->select($relatedpost_query);
			if($relatedpost){
				while($rresult=$relatedpost->fetch_assoc()){
           ?>
					<a href="post.php?post_id=<?php echo $rresult['post_id']; ?>">
					<img src="admin/<?php echo $rresult['image']; ?>" alt="post image"/>
				</a>
					
		<?php } } ?>
				</div>

	<?php } } else { echo  header("Location:404.php") ;} ?>	
	</div>
</div>
			
    <?php include "inc/sidebar.php" ?>	
	<?php include "inc/footer.php" ?>