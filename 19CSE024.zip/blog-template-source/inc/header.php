<?php include "define/definedb.php"; ?>
<?php include "lib/database.php" ; ?>
<?php include "others/format.php" ; ?>
<?php 
 $db=new Database();
 $fm=new Format();
?>
<?php
  header("Cache-Control: no-cache, must-revalidate"); 
  header("Pragma: no-cache"); 
  header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); 
  header("Cache-Control: max-age=2592000");
?>
<!DOCTYPE html>
<html>
<head>

    <?php include'script/meta.php';?>
	<?php include'script/css.php';?>
	<?php include'script/js.php';?>
	
</head>

<body>
	<div class="headersection templete clear">
		<a href="index.php">
			<div class="logo">
				<?php
  $query="select * from title_logo where id=1";
  $titlequery=$db->select($query);
  if($titlequery){
	  while($result=$titlequery->fetch_assoc()){

  ?>
				<img src="admin/<?php echo $result['logo']; ?>" alt="Logo"/>
				<h2><?php echo $result['title']; ?></h2>
				<p><?php echo $result['slogan']; ?></p>
			<?php } } ?>
			</div>
		</a>
		<div class="social clear">
			<div class="icon clear">
			
           <!-- $query="select * from social_media where id=1";
            $socialquery=$db->select($query);
            if($socialquery){
                while($result=$socialquery->fetch_assoc()){

                  
			<a href="<?php echo $result['facebook'];?>" target="_blank"><i class="fa fa-facebook"></i></a>
				<a href="<?php echo $result['twitter'];?>" target="_blank"><i class="fa fa-twitter"></i></a>
				<a href="<?php echo $result['linkedin'];?>" target="_blank"><i class="fa fa-linkedin"></i></a>
				<a href="<?php echo $result['google'];?>" target="_blank"><i class="fa fa-google-plus"3</i></a>
				-->
			
			<a href="https:facebook.com"><img src="images/fb.png" alt="facebook" style="width:20px;height:30px;"></a>
			<a href="https:facebook.com"><img src="images/twitter.png" alt="twitter" style="width:20px;height:30px;"></a>
			<a href="https:facebook.com"><img src="images/linkedin.jpg" alt="facebook" style="width:20px;height:30px;"></a>
			<a href="https:facebook.com"><img src="images/Google.png" alt="facebook" style="width:20px;height:30px;"></a>
			</div>
			<div class="searchbtn clear">
			<form action="search.php" method="get">
				<input type="text" name="search" placeholder="Search......"/>
				<input type="submit" name="submit" value="Search"/>
			</form>
			</div>
		</div>
	</div>
<div class="navsection templete">
	<?php 
   $path=$_SERVER['SCRIPT_FILENAME'];
   $currentpage=basename($path,'.php');
   ?>

	<ul>
		<li><a  
		<?php if($currentpage=='index'){
			echo 'id="active"';
		}?>
		href="index.php">Home</a></li>
		<?php
            $query="select * from page";
            $pagequery=$db->select($query);
            if($pagequery){
                while($result=$pagequery->fetch_assoc()){

            ?>
        <li><a
		<?php 
         if(isset($_GET['pageid']) && $_GET['pageid']==$result['id']){
			 echo 'id="active"';
		 }
		?>
		 href="page.php?pageid=<?php echo $result['id'];?>"><?php echo $result['name'];?></a> </li>
        <?php } } ?>
		<li><a <?php if($currentpage=='contact'){
			echo 'id="active"';
		}?> href="contact.php">Contact</a></li>
	</ul>
</div>