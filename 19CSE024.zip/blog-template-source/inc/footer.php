
<div class="footersection templete clear">
	  <div class="footermenu clear">
		<!--<ul>
			<li><a href="#">Home</a></li>
			<li><a href="#">About</a></li>
			<li><a href="#">Contact</a></li>
			<li><a href="#">Privacy</a></li>
		</ul>-->
		<div class="left box">
			<h2>Quick Links</h2>
			 <ul>
			     <li><a href="index.php">Home</a></li>
			     <li><a href="page.php">About</a></li>
				 <li><a href="page.php">Privacy</a></li>
			     <li><a href="contact.php">Contact</a></li>
			     
		    </ul>
		</div>
		<div class="right box">
		<h2>Contact Info</h2>
			<div class="content">
				<div class="email">
					<span class="fas fa-envelope"></span>
					<span style='font-size:18px'>studymate@gmail.com</span>
				</div>
				<div class="phone">
					<span class="fas fa-phone-alt"></span>
					<span style='font-size:18px'>0928726324</span>
				</div>
				<div class="social clear">
				<div class="icon clear">
			<!--
            $query="select * from social_media where id=1";
            $socialquery=$db->select($query);
            if($socialquery){
                while($result=$socialquery->fetch_assoc()){

            ?>        
				<a href="<?php echo $result['facebook'];?>" target="_blank"><i class="fa fa-facebook"></i></a>
				<a href="<?php echo $result['twitter'];?>" target="_blank"><i class="fa fa-twitter"></i></a>
				<a href="<?php echo $result['linkedin'];?>" target="_blank"><i class="fa fa-linkedin"></i></a>
				<a href="<?php echo $result['google'];?>" target="_blank"><i class="fa fa-google-plus"></i></a>
				-->
				<a href="https:facebook.com"><img src="images/fb.png" alt="facebook" style="width:20px;height:30px;"></a>
			<a href="https:facebook.com"><img src="images/twitter.png" alt="twitter" style="width:20px;height:30px;"></a>
			<a href="https:facebook.com"><img src="images/linkedin.jpg" alt="facebook" style="width:20px;height:30px;"></a>
			<a href="https:facebook.com"><img src="images/Google.png" alt="facebook" style="width:20px;height:30px;"></a>
			
			</div>
			</div>
		</div>
	  </div>
	  </div>
	
	<?php
            $query="select * from footer where id=1";
            $footerquery=$db->select($query);
            if($footerquery){
                while($result=$footerquery->fetch_assoc()){

            ?>   
	  <p>&copy; <?php echo $result['text'];?>
	  <?php echo date('Y'); ?>
	</p>
	  <?php } } ?> 
	</div>	
	<!--<div class="fixedicon clear">
		<a href="http://www.facebook.com"><img src="images/fb.png" alt="Facebook"/></a>
		<a href="http://www.twitter.com"><img src="images/tw.png" alt="Twitter"/></a>
		<a href="http://www.linkedin.com"><img src="images/in.png" alt="LinkedIn"/></a>
		<a href="http://www.google.com"><img src="images/gl.png" alt="GooglePlus"/></a>
	</div>-->
    <script type="text/javascript" src="js/scrolltop.js"></script>
	<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</body>
</html>