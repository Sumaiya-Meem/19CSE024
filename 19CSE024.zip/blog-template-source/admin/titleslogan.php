﻿<?php include "inc/header.php"; ?>
<?php include "inc/sidebar.php"; ?> 
<style>
   .titleside{
   float:left;
   width:70%;
   }
  .logoside{
    float:left;
   width:25%;
   }
   .logoside img{width:200px;height:150px;}
</style>

<div class="grid_10">

    <div class="box round first grid">
        <h2>Update Site Title and Description</h2>
        <?php
if($_SERVER['REQUEST_METHOD']=='POST'){
    $title=$fm->validation($_POST['title']);
   $title=mysqli_real_escape_string($db->link,$title);

   $slogan=$fm->validation($_POST['slogan']);
   $slogan=mysqli_real_escape_string($db->link,$slogan);

   $permited  = array('jpg', 'jpeg', 'png', 'gif');
    $file_name = $_FILES['logo']['name'];
    $file_size = $_FILES['logo']['size'];
    $file_temp = $_FILES['logo']['tmp_name'];

    $div = explode('.', $file_name);
    $file_ext = strtolower(end($div));
    $same_image = 'logo'.'.'.$file_ext;
    $uploaded_image = "upload/".$same_image;

    if($title=="" || $slogan==""){
        echo "<span class='error'>Field must not be empty</span>";
    }
    else{

    if(!empty($file_name )){


    if ($file_size >1048567) {
        echo "<span class='error'>Image Size should be less then 1MB!
        </span>";
        } 
    elseif (in_array($file_ext, $permited) === false) {
    echo "<span class='error'>You can upload only:-"
    .implode(', ', $permited)."</span>";
    } 
    else{
    //move_uploaded_file($file_temp, $uploaded_image);
   // $query = "insert into post(category,title,body,image,author,tags) 
    //VALUES('$category','$title','$body','$uploaded_image','$author','$tags')";

    move_uploaded_file($file_temp, $uploaded_image);
    $updatequery="update title_logo
           set 
           title='$title',
           slogan='$slogan',
           logo='$uploaded_image'
           where id= '1'
    ";
    $updated_rows = $db->update($updatequery);
    if ($updated_rows ) {
    echo "<span class='success'>Data Update.
    </span>";
    }
    else {
    echo "<span class='error'>Update fail!</span>";
    }
    }
}else{
    $updatequery="update title_logo
    set 
    title='$title',
    slogan='$slogan'
    where id='1'
";
$updated_rows = $db->update($updatequery);
if ($updated_rows ) {
echo "<span class='success'>Data Update.
</span>";
}
else {
echo "<span class='error'>Update fail!</span>";
}
}
}
}  
?>
        <?php
            $query="select * from title_logo where id=1";
            $titlequery=$db->select($query);
            if($titlequery){
                while($result=$titlequery->fetch_assoc()){

            ?>
        <div class="block sloginblock">   
        <div class="titleside"> 
            <form action="titleslogan.php" method="post" enctype="multipart/form-data">
            <table class="form">					
                <tr>
                    <td>
                        <label>Website Title</label>
                    </td>
                    <td>
                        <input type="text" value="<?php echo $result['title']; ?>"  name="title" class="medium" />
                    </td>
                </tr>
                    <tr>
                    <td>
                        <label>Website Slogan</label>
                    </td>
                    <td>
                        <input type="text"  value="<?php echo $result['slogan']; ?>"  name="slogan" class="medium" />
                    </td>
                </tr>
                <tr>
                    <td>
                        <label>Website Logo</label>
                    </td>
                    <td>
                        <input type="file"  name="logo" />
                    </td>
                </tr>
                <tr>
                    <td>
                    </td>
                    <td>
                        <input type="submit" name="submit" Value="Update" />
                    </td>
                </tr>
            </table>
            </form>
            </div>
        <div class="imageside">
       <img src="<?php echo $result['logo']; ?>" alt="logo">
        </div>
    </div>
    <?php } } ?>
    </div>
</div>

<?php include "inc/footer.php"; ?>