<?php include "../lib/session.php";
   Session::checksession();  
?>
<?php include "../define/definedb.php"; ?>
<?php include "../lib/database.php" ; ?>
<?php include "../others/format.php" ; ?>
<?php 
 $db=new Database();
?>
<?php
if(!isset($_GET['del_sliderid']) || $_GET['del_sliderid']==NULL){
    header("Location:sliderlist.php");
}
else{
    $delslider_id=$_GET['del_sliderid'];
    $query="select * from slider  where id= '$delslider_id'";
    $getdata=$db->select($query);
    if($getdata){
        while($delimg=$getdata->fetch_assoc()){
            $dellink=$delimg['image'];
            unlink($dellink);
        }
    }
    $delquery="delete from slider where id= '$delslider_id'";
    $deldata=$db->delete($delquery);
    if($deldata){
        echo "<script>alert('Slider deleted successfully');</script>";
        header("Location:sliderlist.php");
    }
    else{
        echo "<script>alert('Slider not deleted');</script>";
        header("Location:sliderlist.php");
    }

}
?>