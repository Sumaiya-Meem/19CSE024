<?php include "../lib/session.php";
   Session::checksession();  
?>
<?php include "../define/definedb.php"; ?>
<?php include "../lib/database.php" ; ?>
<?php 
 $db=new Database();
// $fm=new Format();
?>
<?php
if(!isset($_GET['delpageid'])){
    header("Location:index.php");
}
else{
    $pageid=$_GET['delpageid'];

    $delquery="delete from page where id= '$pageid'";
    $deldata=$db->delete($delquery);
    if($deldata){
        echo "<script>alert('page deleted successfully');</script>";
        header("Location:index.php");
    }
    else{
        echo "<script>alert('Page not deleted');</script>";
        header("Location:index.php");
    }

}
?>