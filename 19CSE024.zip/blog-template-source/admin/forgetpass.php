<?php include "../lib/session.php";
 Session::checklogin();
?>

<?php include "../define/definedb.php"; ?>
<?php include "../lib/database.php" ; ?>
<?php include "../others/format.php" ; ?>
<?php 
 $db=new Database();
 $fm=new Format();
?>


<!DOCTYPE html>
<head>
<meta charset="utf-8">
<title>Recover password</title>
    <link rel="stylesheet" type="text/css" href="css/stylelogin.css" media="screen" />
</head>
<body>
<div class="container">
	<section id="content">
		<?php
		if($_SERVER['REQUEST_METHOD']=='POST'){
            $email=$fm->validation($_POST['email']);
		   $email=mysqli_real_escape_string($db->link,$email);
           if(!filter_var($email,FILTER_VALIDATE_EMAIL)){
            echo "<span style='color:red;font-size:18px;'>Invalid Email</span>";
		   }
           else{
        $mailquery="select * from user where email='$email' limit 1";
        $mailcheck=$db->select($mailquery);

        if($mailcheck!=false){
           while($value=$mailcheck->fetch_assoc()){
               $userid=$value['id'];
               $username=$value['username'];
           }
        $text=substr($email,0,3);
        $random=rand(10000,99999);
         $newpass="$text$random";
         $password=md5($newpass);
         $passupdate_query="update user
         SET 
         password='$password'
         where id='$userid'
         ";
    $passupdate_row=$db->update($passupdate_query);
    $to= "$email";
    $from= "sumaiyameem.cse6.bu@gmail.com";
    $headers= "From:$from\n";
    $headers .= "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type: text/html; charset=UTF-8" . "\r\n";
    $subject="Your new password";
    $message="Your username is ".$username." and password is ".$newpass." visit website to login";

    $sendmail=mail($to, $subject, $message, $headers);
    if($sendmail){
        echo "<span style='color:green;font-size:18px;'>Check email</span>";
    }
    else{
        echo "<span style='color:red;font-size:18px;'>Email Not Sent</span>";
    }

		}else{ echo "<span style='color:red;font-size:18px;'>Email Not Exist</span>";}
			} } ?>
		<form action="" method="post">
			<h1>Recover Password</h1>
			<div>
				<input type="text" placeholder="Enter valid email" required="" name="email"/>
			</div>
			<div>
				<input type="submit" value="Send" />
            <a href="login.php" style='color:blue;font-size:18px;'>Login</a>
			</div>
		</form><!-- form -->
		<div class="button">
			<a href="#">Study Mate</a>
		</div><!-- button -->
	</section><!-- content -->
</div><!-- container -->
</body>
</html>