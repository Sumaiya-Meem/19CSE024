<?php include "../lib/session.php";
   Session::checksession();  
?>
<?php include "../define/definedb.php"; ?>
<?php include "../lib/database.php" ; ?>
<?php include "../others/format.php" ; ?>
<?php 
 $db=new Database();
// $fm=new Format();
?>
<?php
if(!isset($_GET['delpostid'])){
    header("Location:postlist.php");
}
else{
    $postid=$_GET['delpostid'];
    $query="select * from post where post_id= '$postid'";
    $getdata=$db->select($query);
    if($getdata){
        while($delimg=$getdata->fetch_assoc()){
            $dellink=$delimg['image'];
            unlink($dellink);
        }
    }
    $delquery="delete from post where post_id= '$postid'";
    $deldata=$db->delete($delquery);
    if($deldata){
        echo "<script>alert('Data deleted successfully');</script>";
        header("Location:postlist.php");
    }
    else{
        echo "<script>alert('Data not deleted');</script>";
        header("Location:postlist.php");
    }

}
?>