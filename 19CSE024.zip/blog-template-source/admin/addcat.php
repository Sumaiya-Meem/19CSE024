﻿<?php include "inc/header.php"; ?>
<?php include "inc/sidebar.php"; ?>  

        <div class="grid_10">
		
            <div class="box round first grid">
                <h2>Add New Category</h2>
               <div class="block copyblock"> 
    <?php
		if($_SERVER['REQUEST_METHOD']=='POST'){
            $cat_name=$_POST['cat_name']; 
		   $cat_name=mysqli_real_escape_string($db->link,$cat_name);
		   if(empty($cat_name)){
               echo "<span class='error'>enter valid name..</span>";
           }
           else{
               $query="insert into category(cat_name) values('$cat_name')";
               $cat_insert=$db->insert($query);
               if($cat_insert){
                echo "<span class='success'>insert successfully</span>";
               }
               else{
                echo "<span class='error'>insertion fail</span>";
               }
           }

        }
 ?>
                 <form action="" method="post">
                    <table class="form">					
                        <tr>
                            <td>
                                <input type="text" name="cat_name" placeholder="Enter Category Name..." class="medium" />
                            </td>
                        </tr>
						<tr> 
                            <td>
                                <input type="submit" name="submit" Value="Save" />
                            </td>
                        </tr>
                    </table>
                    </form>
                </div>
            </div>
        </div>

<?php include "inc/footer.php"; ?>
