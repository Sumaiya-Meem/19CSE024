<?php include "inc/header.php"; ?>
<?php
   if(!isset($_GET['search']) || $_GET['search'] == NULL ){
	echo "s";
   }
   else{
	   $search=$_GET['search'];
   }
?>
	<div class="contentsection contemplete clear">
		<div class="maincontent clear">

        <?php 
  $query="select * from post where title LIKE '%$search%' OR body LIKE '%$search%' ";
  $post=$db->select($query);
  if($post){
	  while($result=$post->fetch_assoc()){
?>	

            <div class="samepost clear">
				<h2><a href="post.php?post_id=<?php echo $result['post_id']; ?>"><?php echo $result['title']; ?></a></h2>
				<h4><?php echo  $fm->dateFormat($result['date']); ?> By <a href="#"><?php echo $result['author']; ?></a></h4>
				 <a href="#"><img src="admin/<?php echo $result['image']; ?>" alt="post image"/></a>
				 <?php echo $fm->readmore($result['body']); ?>
				<div class="readmore clear">
				<a href="post.php?post_id=<?php echo $result['post_id']; ?>">Read More</a></div>
		    </div>
    <?php } } else {header("Location:404.php") ;} ?>	

     </div><!--maincontent-dive-end-->
     
<?php include "inc/sidebar.php" ?>
</div>
<?php include "inc/footer.php" ?>