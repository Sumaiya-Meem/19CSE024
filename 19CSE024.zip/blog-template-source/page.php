<?php include "inc/header.php"; ?>
<?php
if(!isset($_GET['pageid'])){
    header("Location:404.php");
}
else{
    $id=$_GET['pageid'];
}
?>
<div class="about">
			<?php
            $pagequery="select * from page where id='$id'";
            $pagesquery=$db->select($pagequery);
            if($pagesquery){
                while($result=$pagesquery->fetch_assoc()){

            ?>
	<div class="contentsection contemplete clear">
		<div class="maincontent clear">
				<h2><?php echo $result['name'];?></h2>
				<?php echo $result['body'];?>
			</div>
            <?php include "inc/sidebar.php" ?>
</div>
<?php } } else{ header("Location:404.php");} ?>
    
	<?php include "inc/footer.php" ?>